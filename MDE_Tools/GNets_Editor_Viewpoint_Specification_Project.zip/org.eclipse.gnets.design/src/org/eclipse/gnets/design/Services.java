package org.eclipse.gnets.design;

import java.util.List;

import org.eclipse.emf.ecore.EObject;

import ogr.eclipse.gnets.*;


/**
 * The services class used by VSM.
 */
public class Services {
    
    /**
    * See http://help.eclipse.org/neon/index.jsp?topic=%2Forg.eclipse.sirius.doc%2Fdoc%2Findex.html&cp=24 for documentation on how to write service methods.
    */
    public String fonction(Method method) {
       // TODO Auto-generated code
    	String St ="[" ;
    	List<Attribute> attributes = method.getAttributes();
    	for ( Attribute att : attributes)
    	{
    		St = St + att.getName() + " : " + att.getType();
    		}
    	St = St +"] (";
    	List<Place> initials = method.getInitials();
    	Integer i= 1;
    	for ( Place init : initials)
    	{
    		St = St + init.getName();
    		if (i<initials.size()) 
    		{
    			St = St + " ,";
    		}
    		i++;
    		}
    	St = St +") (";
    	List<Place> finals = method.getFinals();
    	for ( Place fin : finals)
    	{
    		St = St + fin.getName();
    		}
    	St = St +")";
      return method.getName() + " : " + St;
    }
}
