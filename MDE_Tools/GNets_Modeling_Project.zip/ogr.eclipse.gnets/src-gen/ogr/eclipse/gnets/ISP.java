/**
 */
package ogr.eclipse.gnets;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ISP</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ogr.eclipse.gnets.ISP#getInvoked <em>Invoked</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.ISP#getUsing <em>Using</em>}</li>
 * </ul>
 *
 * @see ogr.eclipse.gnets.GnetsPackage#getISP()
 * @model
 * @generated
 */
public interface ISP extends Place {
	/**
	 * Returns the value of the '<em><b>Invoked</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Invoked</em>' reference.
	 * @see #setInvoked(GNet)
	 * @see ogr.eclipse.gnets.GnetsPackage#getISP_Invoked()
	 * @model
	 * @generated
	 */
	GNet getInvoked();

	/**
	 * Sets the value of the '{@link ogr.eclipse.gnets.ISP#getInvoked <em>Invoked</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Invoked</em>' reference.
	 * @see #getInvoked()
	 * @generated
	 */
	void setInvoked(GNet value);

	/**
	 * Returns the value of the '<em><b>Using</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Using</em>' reference.
	 * @see #setUsing(Method)
	 * @see ogr.eclipse.gnets.GnetsPackage#getISP_Using()
	 * @model
	 * @generated
	 */
	Method getUsing();

	/**
	 * Sets the value of the '{@link ogr.eclipse.gnets.ISP#getUsing <em>Using</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Using</em>' reference.
	 * @see #getUsing()
	 * @generated
	 */
	void setUsing(Method value);

} // ISP
