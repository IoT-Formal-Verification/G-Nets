/**
 */
package ogr.eclipse.gnets.impl;

import ogr.eclipse.gnets.GP;
import ogr.eclipse.gnets.GnetsPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>GP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class GPImpl extends PlaceImpl implements GP {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GPImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GnetsPackage.Literals.GP;
	}

} //GPImpl
