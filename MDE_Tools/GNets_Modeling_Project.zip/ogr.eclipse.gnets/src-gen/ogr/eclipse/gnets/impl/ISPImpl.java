/**
 */
package ogr.eclipse.gnets.impl;

import ogr.eclipse.gnets.GNet;
import ogr.eclipse.gnets.GnetsPackage;
import ogr.eclipse.gnets.ISP;

import ogr.eclipse.gnets.Method;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ISP</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ogr.eclipse.gnets.impl.ISPImpl#getInvoked <em>Invoked</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.impl.ISPImpl#getUsing <em>Using</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ISPImpl extends PlaceImpl implements ISP {
	/**
	 * The cached value of the '{@link #getInvoked() <em>Invoked</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInvoked()
	 * @generated
	 * @ordered
	 */
	protected GNet invoked;

	/**
	 * The cached value of the '{@link #getUsing() <em>Using</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsing()
	 * @generated
	 * @ordered
	 */
	protected Method using;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ISPImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GnetsPackage.Literals.ISP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GNet getInvoked() {
		if (invoked != null && invoked.eIsProxy()) {
			InternalEObject oldInvoked = (InternalEObject) invoked;
			invoked = (GNet) eResolveProxy(oldInvoked);
			if (invoked != oldInvoked) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, GnetsPackage.ISP__INVOKED, oldInvoked,
							invoked));
			}
		}
		return invoked;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GNet basicGetInvoked() {
		return invoked;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInvoked(GNet newInvoked) {
		GNet oldInvoked = invoked;
		invoked = newInvoked;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, GnetsPackage.ISP__INVOKED, oldInvoked, invoked));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Method getUsing() {
		if (using != null && using.eIsProxy()) {
			InternalEObject oldUsing = (InternalEObject) using;
			using = (Method) eResolveProxy(oldUsing);
			if (using != oldUsing) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, GnetsPackage.ISP__USING, oldUsing,
							using));
			}
		}
		return using;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Method basicGetUsing() {
		return using;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUsing(Method newUsing) {
		Method oldUsing = using;
		using = newUsing;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, GnetsPackage.ISP__USING, oldUsing, using));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case GnetsPackage.ISP__INVOKED:
			if (resolve)
				return getInvoked();
			return basicGetInvoked();
		case GnetsPackage.ISP__USING:
			if (resolve)
				return getUsing();
			return basicGetUsing();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case GnetsPackage.ISP__INVOKED:
			setInvoked((GNet) newValue);
			return;
		case GnetsPackage.ISP__USING:
			setUsing((Method) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case GnetsPackage.ISP__INVOKED:
			setInvoked((GNet) null);
			return;
		case GnetsPackage.ISP__USING:
			setUsing((Method) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case GnetsPackage.ISP__INVOKED:
			return invoked != null;
		case GnetsPackage.ISP__USING:
			return using != null;
		}
		return super.eIsSet(featureID);
	}

} //ISPImpl
