/**
 */
package ogr.eclipse.gnets.impl;

import ogr.eclipse.gnets.GnetsPackage;
import ogr.eclipse.gnets.NP;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>NP</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NPImpl extends PlaceImpl implements NP {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NPImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GnetsPackage.Literals.NP;
	}

} //NPImpl
