/**
 */
package ogr.eclipse.gnets.impl;

import ogr.eclipse.gnets.GNet;
import ogr.eclipse.gnets.GSP;
import ogr.eclipse.gnets.GnetsPackage;
import ogr.eclipse.gnets.IS;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>GNet</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ogr.eclipse.gnets.impl.GNetImpl#getGsp <em>Gsp</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.impl.GNetImpl#getIs <em>Is</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.impl.GNetImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GNetImpl extends MinimalEObjectImpl.Container implements GNet {
	/**
	 * The cached value of the '{@link #getGsp() <em>Gsp</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGsp()
	 * @generated
	 * @ordered
	 */
	protected GSP gsp;

	/**
	 * The cached value of the '{@link #getIs() <em>Is</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs()
	 * @generated
	 * @ordered
	 */
	protected IS is;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GNetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GnetsPackage.Literals.GNET;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GSP getGsp() {
		return gsp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetGsp(GSP newGsp, NotificationChain msgs) {
		GSP oldGsp = gsp;
		gsp = newGsp;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, GnetsPackage.GNET__GSP,
					oldGsp, newGsp);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGsp(GSP newGsp) {
		if (newGsp != gsp) {
			NotificationChain msgs = null;
			if (gsp != null)
				msgs = ((InternalEObject) gsp).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - GnetsPackage.GNET__GSP,
						null, msgs);
			if (newGsp != null)
				msgs = ((InternalEObject) newGsp).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - GnetsPackage.GNET__GSP,
						null, msgs);
			msgs = basicSetGsp(newGsp, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, GnetsPackage.GNET__GSP, newGsp, newGsp));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IS getIs() {
		return is;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIs(IS newIs, NotificationChain msgs) {
		IS oldIs = is;
		is = newIs;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, GnetsPackage.GNET__IS, oldIs,
					newIs);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs(IS newIs) {
		if (newIs != is) {
			NotificationChain msgs = null;
			if (is != null)
				msgs = ((InternalEObject) is).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - GnetsPackage.GNET__IS, null,
						msgs);
			if (newIs != null)
				msgs = ((InternalEObject) newIs).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - GnetsPackage.GNET__IS, null,
						msgs);
			msgs = basicSetIs(newIs, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, GnetsPackage.GNET__IS, newIs, newIs));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, GnetsPackage.GNET__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case GnetsPackage.GNET__GSP:
			return basicSetGsp(null, msgs);
		case GnetsPackage.GNET__IS:
			return basicSetIs(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case GnetsPackage.GNET__GSP:
			return getGsp();
		case GnetsPackage.GNET__IS:
			return getIs();
		case GnetsPackage.GNET__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case GnetsPackage.GNET__GSP:
			setGsp((GSP) newValue);
			return;
		case GnetsPackage.GNET__IS:
			setIs((IS) newValue);
			return;
		case GnetsPackage.GNET__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case GnetsPackage.GNET__GSP:
			setGsp((GSP) null);
			return;
		case GnetsPackage.GNET__IS:
			setIs((IS) null);
			return;
		case GnetsPackage.GNET__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case GnetsPackage.GNET__GSP:
			return gsp != null;
		case GnetsPackage.GNET__IS:
			return is != null;
		case GnetsPackage.GNET__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //GNetImpl
