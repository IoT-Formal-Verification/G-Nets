/**
 */
package ogr.eclipse.gnets.impl;

import ogr.eclipse.gnets.GnetsPackage;
import ogr.eclipse.gnets.Place;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Place</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ogr.eclipse.gnets.impl.PlaceImpl#isIsLocalToken <em>Is Local Token</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.impl.PlaceImpl#getTokens <em>Tokens</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class PlaceImpl extends NodeImpl implements Place {
	/**
	 * The default value of the '{@link #isIsLocalToken() <em>Is Local Token</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsLocalToken()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_LOCAL_TOKEN_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsLocalToken() <em>Is Local Token</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsLocalToken()
	 * @generated
	 * @ordered
	 */
	protected boolean isLocalToken = IS_LOCAL_TOKEN_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTokens() <em>Tokens</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTokens()
	 * @generated
	 * @ordered
	 */
	protected EList tokens;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlaceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GnetsPackage.Literals.PLACE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTokens() {
		return tokens;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTokens(EList newTokens) {
		EList oldTokens = tokens;
		tokens = newTokens;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, GnetsPackage.PLACE__TOKENS, oldTokens, tokens));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsLocalToken() {
		return isLocalToken;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsLocalToken(boolean newIsLocalToken) {
		boolean oldIsLocalToken = isLocalToken;
		isLocalToken = newIsLocalToken;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, GnetsPackage.PLACE__IS_LOCAL_TOKEN, oldIsLocalToken,
					isLocalToken));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case GnetsPackage.PLACE__IS_LOCAL_TOKEN:
			return isIsLocalToken();
		case GnetsPackage.PLACE__TOKENS:
			return getTokens();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case GnetsPackage.PLACE__IS_LOCAL_TOKEN:
			setIsLocalToken((Boolean) newValue);
			return;
		case GnetsPackage.PLACE__TOKENS:
			setTokens((EList) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case GnetsPackage.PLACE__IS_LOCAL_TOKEN:
			setIsLocalToken(IS_LOCAL_TOKEN_EDEFAULT);
			return;
		case GnetsPackage.PLACE__TOKENS:
			setTokens((EList) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case GnetsPackage.PLACE__IS_LOCAL_TOKEN:
			return isLocalToken != IS_LOCAL_TOKEN_EDEFAULT;
		case GnetsPackage.PLACE__TOKENS:
			return tokens != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (IsLocalToken: ");
		result.append(isLocalToken);
		result.append(", tokens: ");
		result.append(tokens);
		result.append(')');
		return result.toString();
	}

} //PlaceImpl
