/**
 */
package ogr.eclipse.gnets;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>GNet</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ogr.eclipse.gnets.GNet#getGsp <em>Gsp</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.GNet#getIs <em>Is</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.GNet#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see ogr.eclipse.gnets.GnetsPackage#getGNet()
 * @model
 * @generated
 */
public interface GNet extends EObject {
	/**
	 * Returns the value of the '<em><b>Gsp</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gsp</em>' containment reference.
	 * @see #setGsp(GSP)
	 * @see ogr.eclipse.gnets.GnetsPackage#getGNet_Gsp()
	 * @model containment="true" required="true"
	 * @generated
	 */
	GSP getGsp();

	/**
	 * Sets the value of the '{@link ogr.eclipse.gnets.GNet#getGsp <em>Gsp</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Gsp</em>' containment reference.
	 * @see #getGsp()
	 * @generated
	 */
	void setGsp(GSP value);

	/**
	 * Returns the value of the '<em><b>Is</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is</em>' containment reference.
	 * @see #setIs(IS)
	 * @see ogr.eclipse.gnets.GnetsPackage#getGNet_Is()
	 * @model containment="true" required="true"
	 * @generated
	 */
	IS getIs();

	/**
	 * Sets the value of the '{@link ogr.eclipse.gnets.GNet#getIs <em>Is</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is</em>' containment reference.
	 * @see #getIs()
	 * @generated
	 */
	void setIs(IS value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ogr.eclipse.gnets.GnetsPackage#getGNet_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ogr.eclipse.gnets.GNet#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // GNet
