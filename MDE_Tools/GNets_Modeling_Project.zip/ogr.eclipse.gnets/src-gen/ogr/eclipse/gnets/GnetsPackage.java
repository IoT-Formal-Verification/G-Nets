/**
 */
package ogr.eclipse.gnets;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see ogr.eclipse.gnets.GnetsFactory
 * @model kind="package"
 * @generated
 */
public interface GnetsPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "gnets";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/gnets";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "gnets";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	GnetsPackage eINSTANCE = ogr.eclipse.gnets.impl.GnetsPackageImpl.init();

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.GNetImpl <em>GNet</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.GNetImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getGNet()
	 * @generated
	 */
	int GNET = 0;

	/**
	 * The feature id for the '<em><b>Gsp</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNET__GSP = 0;

	/**
	 * The feature id for the '<em><b>Is</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNET__IS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNET__NAME = 2;

	/**
	 * The number of structural features of the '<em>GNet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNET_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>GNet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNET_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.GSPImpl <em>GSP</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.GSPImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getGSP()
	 * @generated
	 */
	int GSP = 1;

	/**
	 * The feature id for the '<em><b>AS</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GSP__AS = 0;

	/**
	 * The feature id for the '<em><b>MS</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GSP__MS = 1;

	/**
	 * The number of structural features of the '<em>GSP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GSP_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>GSP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GSP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.ISImpl <em>IS</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.ISImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getIS()
	 * @generated
	 */
	int IS = 2;

	/**
	 * The feature id for the '<em><b>Nodes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IS__NODES = 0;

	/**
	 * The feature id for the '<em><b>Arcs</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IS__ARCS = 1;

	/**
	 * The number of structural features of the '<em>IS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IS_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>IS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.NodeImpl <em>Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.NodeImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getNode()
	 * @generated
	 */
	int NODE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__ACTION = 1;

	/**
	 * The number of structural features of the '<em>Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.TransitionImpl <em>Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.TransitionImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getTransition()
	 * @generated
	 */
	int TRANSITION = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__NAME = NODE__NAME;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__ACTION = NODE__ACTION;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__CONDITION = NODE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_FEATURE_COUNT = NODE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_OPERATION_COUNT = NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.PlaceImpl <em>Place</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.PlaceImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getPlace()
	 * @generated
	 */
	int PLACE = 12;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.ArcImpl <em>Arc</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.ArcImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getArc()
	 * @generated
	 */
	int ARC = 4;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARC__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARC__TARGET = 1;

	/**
	 * The number of structural features of the '<em>Arc</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARC_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Arc</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARC_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACE__NAME = NODE__NAME;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACE__ACTION = NODE__ACTION;

	/**
	 * The feature id for the '<em><b>Is Local Token</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACE__IS_LOCAL_TOKEN = NODE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Tokens</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACE__TOKENS = NODE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Place</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACE_FEATURE_COUNT = NODE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Place</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACE_OPERATION_COUNT = NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.GPImpl <em>GP</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.GPImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getGP()
	 * @generated
	 */
	int GP = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GP__NAME = PLACE__NAME;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GP__ACTION = PLACE__ACTION;

	/**
	 * The feature id for the '<em><b>Is Local Token</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GP__IS_LOCAL_TOKEN = PLACE__IS_LOCAL_TOKEN;

	/**
	 * The feature id for the '<em><b>Tokens</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GP__TOKENS = PLACE__TOKENS;

	/**
	 * The number of structural features of the '<em>GP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GP_FEATURE_COUNT = PLACE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>GP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GP_OPERATION_COUNT = PLACE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.NPImpl <em>NP</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.NPImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getNP()
	 * @generated
	 */
	int NP = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NP__NAME = PLACE__NAME;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NP__ACTION = PLACE__ACTION;

	/**
	 * The feature id for the '<em><b>Is Local Token</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NP__IS_LOCAL_TOKEN = PLACE__IS_LOCAL_TOKEN;

	/**
	 * The feature id for the '<em><b>Tokens</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NP__TOKENS = PLACE__TOKENS;

	/**
	 * The number of structural features of the '<em>NP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NP_FEATURE_COUNT = PLACE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>NP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NP_OPERATION_COUNT = PLACE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.ISPImpl <em>ISP</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.ISPImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getISP()
	 * @generated
	 */
	int ISP = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISP__NAME = PLACE__NAME;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISP__ACTION = PLACE__ACTION;

	/**
	 * The feature id for the '<em><b>Is Local Token</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISP__IS_LOCAL_TOKEN = PLACE__IS_LOCAL_TOKEN;

	/**
	 * The feature id for the '<em><b>Tokens</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISP__TOKENS = PLACE__TOKENS;

	/**
	 * The feature id for the '<em><b>Invoked</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISP__INVOKED = PLACE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Using</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISP__USING = PLACE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>ISP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISP_FEATURE_COUNT = PLACE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>ISP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISP_OPERATION_COUNT = PLACE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.GNets_SpecificationImpl <em>GNets Specification</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.GNets_SpecificationImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getGNets_Specification()
	 * @generated
	 */
	int GNETS_SPECIFICATION = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNETS_SPECIFICATION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Gnets</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNETS_SPECIFICATION__GNETS = 1;

	/**
	 * The number of structural features of the '<em>GNets Specification</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNETS_SPECIFICATION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>GNets Specification</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GNETS_SPECIFICATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.AttributeImpl <em>Attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.AttributeImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getAttribute()
	 * @generated
	 */
	int ATTRIBUTE = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__TYPE = 1;

	/**
	 * The number of structural features of the '<em>Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.impl.MethodImpl <em>Method</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.impl.MethodImpl
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getMethod()
	 * @generated
	 */
	int METHOD = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD__NAME = 0;

	/**
	 * The feature id for the '<em><b>Initials</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD__INITIALS = 1;

	/**
	 * The feature id for the '<em><b>Finals</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD__FINALS = 2;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD__ATTRIBUTES = 3;

	/**
	 * The number of structural features of the '<em>Method</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Method</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ogr.eclipse.gnets.Type <em>Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ogr.eclipse.gnets.Type
	 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getType()
	 * @generated
	 */
	int TYPE = 13;

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.GNet <em>GNet</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>GNet</em>'.
	 * @see ogr.eclipse.gnets.GNet
	 * @generated
	 */
	EClass getGNet();

	/**
	 * Returns the meta object for the containment reference '{@link ogr.eclipse.gnets.GNet#getGsp <em>Gsp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Gsp</em>'.
	 * @see ogr.eclipse.gnets.GNet#getGsp()
	 * @see #getGNet()
	 * @generated
	 */
	EReference getGNet_Gsp();

	/**
	 * Returns the meta object for the containment reference '{@link ogr.eclipse.gnets.GNet#getIs <em>Is</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Is</em>'.
	 * @see ogr.eclipse.gnets.GNet#getIs()
	 * @see #getGNet()
	 * @generated
	 */
	EReference getGNet_Is();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.GNet#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ogr.eclipse.gnets.GNet#getName()
	 * @see #getGNet()
	 * @generated
	 */
	EAttribute getGNet_Name();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.GSP <em>GSP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>GSP</em>'.
	 * @see ogr.eclipse.gnets.GSP
	 * @generated
	 */
	EClass getGSP();

	/**
	 * Returns the meta object for the containment reference list '{@link ogr.eclipse.gnets.GSP#getAS <em>AS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>AS</em>'.
	 * @see ogr.eclipse.gnets.GSP#getAS()
	 * @see #getGSP()
	 * @generated
	 */
	EReference getGSP_AS();

	/**
	 * Returns the meta object for the containment reference list '{@link ogr.eclipse.gnets.GSP#getMS <em>MS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>MS</em>'.
	 * @see ogr.eclipse.gnets.GSP#getMS()
	 * @see #getGSP()
	 * @generated
	 */
	EReference getGSP_MS();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.IS <em>IS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IS</em>'.
	 * @see ogr.eclipse.gnets.IS
	 * @generated
	 */
	EClass getIS();

	/**
	 * Returns the meta object for the containment reference list '{@link ogr.eclipse.gnets.IS#getNodes <em>Nodes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Nodes</em>'.
	 * @see ogr.eclipse.gnets.IS#getNodes()
	 * @see #getIS()
	 * @generated
	 */
	EReference getIS_Nodes();

	/**
	 * Returns the meta object for the containment reference list '{@link ogr.eclipse.gnets.IS#getArcs <em>Arcs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Arcs</em>'.
	 * @see ogr.eclipse.gnets.IS#getArcs()
	 * @see #getIS()
	 * @generated
	 */
	EReference getIS_Arcs();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.Transition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transition</em>'.
	 * @see ogr.eclipse.gnets.Transition
	 * @generated
	 */
	EClass getTransition();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.Transition#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Condition</em>'.
	 * @see ogr.eclipse.gnets.Transition#getCondition()
	 * @see #getTransition()
	 * @generated
	 */
	EAttribute getTransition_Condition();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.Place <em>Place</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Place</em>'.
	 * @see ogr.eclipse.gnets.Place
	 * @generated
	 */
	EClass getPlace();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.Place#getTokens <em>Tokens</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tokens</em>'.
	 * @see ogr.eclipse.gnets.Place#getTokens()
	 * @see #getPlace()
	 * @generated
	 */
	EAttribute getPlace_Tokens();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.Place#isIsLocalToken <em>Is Local Token</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Local Token</em>'.
	 * @see ogr.eclipse.gnets.Place#isIsLocalToken()
	 * @see #getPlace()
	 * @generated
	 */
	EAttribute getPlace_IsLocalToken();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.Arc <em>Arc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Arc</em>'.
	 * @see ogr.eclipse.gnets.Arc
	 * @generated
	 */
	EClass getArc();

	/**
	 * Returns the meta object for the reference '{@link ogr.eclipse.gnets.Arc#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see ogr.eclipse.gnets.Arc#getSource()
	 * @see #getArc()
	 * @generated
	 */
	EReference getArc_Source();

	/**
	 * Returns the meta object for the reference '{@link ogr.eclipse.gnets.Arc#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see ogr.eclipse.gnets.Arc#getTarget()
	 * @see #getArc()
	 * @generated
	 */
	EReference getArc_Target();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.Node <em>Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Node</em>'.
	 * @see ogr.eclipse.gnets.Node
	 * @generated
	 */
	EClass getNode();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.Node#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ogr.eclipse.gnets.Node#getName()
	 * @see #getNode()
	 * @generated
	 */
	EAttribute getNode_Name();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.Node#getAction <em>Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Action</em>'.
	 * @see ogr.eclipse.gnets.Node#getAction()
	 * @see #getNode()
	 * @generated
	 */
	EAttribute getNode_Action();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.GP <em>GP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>GP</em>'.
	 * @see ogr.eclipse.gnets.GP
	 * @generated
	 */
	EClass getGP();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.NP <em>NP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>NP</em>'.
	 * @see ogr.eclipse.gnets.NP
	 * @generated
	 */
	EClass getNP();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.ISP <em>ISP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>ISP</em>'.
	 * @see ogr.eclipse.gnets.ISP
	 * @generated
	 */
	EClass getISP();

	/**
	 * Returns the meta object for the reference '{@link ogr.eclipse.gnets.ISP#getInvoked <em>Invoked</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Invoked</em>'.
	 * @see ogr.eclipse.gnets.ISP#getInvoked()
	 * @see #getISP()
	 * @generated
	 */
	EReference getISP_Invoked();

	/**
	 * Returns the meta object for the reference '{@link ogr.eclipse.gnets.ISP#getUsing <em>Using</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Using</em>'.
	 * @see ogr.eclipse.gnets.ISP#getUsing()
	 * @see #getISP()
	 * @generated
	 */
	EReference getISP_Using();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.GNets_Specification <em>GNets Specification</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>GNets Specification</em>'.
	 * @see ogr.eclipse.gnets.GNets_Specification
	 * @generated
	 */
	EClass getGNets_Specification();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.GNets_Specification#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ogr.eclipse.gnets.GNets_Specification#getName()
	 * @see #getGNets_Specification()
	 * @generated
	 */
	EAttribute getGNets_Specification_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link ogr.eclipse.gnets.GNets_Specification#getGnets <em>Gnets</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Gnets</em>'.
	 * @see ogr.eclipse.gnets.GNets_Specification#getGnets()
	 * @see #getGNets_Specification()
	 * @generated
	 */
	EReference getGNets_Specification_Gnets();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.Attribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute</em>'.
	 * @see ogr.eclipse.gnets.Attribute
	 * @generated
	 */
	EClass getAttribute();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.Attribute#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ogr.eclipse.gnets.Attribute#getName()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Name();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.Attribute#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see ogr.eclipse.gnets.Attribute#getType()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Type();

	/**
	 * Returns the meta object for class '{@link ogr.eclipse.gnets.Method <em>Method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Method</em>'.
	 * @see ogr.eclipse.gnets.Method
	 * @generated
	 */
	EClass getMethod();

	/**
	 * Returns the meta object for the attribute '{@link ogr.eclipse.gnets.Method#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ogr.eclipse.gnets.Method#getName()
	 * @see #getMethod()
	 * @generated
	 */
	EAttribute getMethod_Name();

	/**
	 * Returns the meta object for the reference list '{@link ogr.eclipse.gnets.Method#getInitials <em>Initials</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Initials</em>'.
	 * @see ogr.eclipse.gnets.Method#getInitials()
	 * @see #getMethod()
	 * @generated
	 */
	EReference getMethod_Initials();

	/**
	 * Returns the meta object for the reference list '{@link ogr.eclipse.gnets.Method#getFinals <em>Finals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Finals</em>'.
	 * @see ogr.eclipse.gnets.Method#getFinals()
	 * @see #getMethod()
	 * @generated
	 */
	EReference getMethod_Finals();

	/**
	 * Returns the meta object for the reference list '{@link ogr.eclipse.gnets.Method#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Attributes</em>'.
	 * @see ogr.eclipse.gnets.Method#getAttributes()
	 * @see #getMethod()
	 * @generated
	 */
	EReference getMethod_Attributes();

	/**
	 * Returns the meta object for enum '{@link ogr.eclipse.gnets.Type <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type</em>'.
	 * @see ogr.eclipse.gnets.Type
	 * @generated
	 */
	EEnum getType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	GnetsFactory getGnetsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.GNetImpl <em>GNet</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.GNetImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getGNet()
		 * @generated
		 */
		EClass GNET = eINSTANCE.getGNet();

		/**
		 * The meta object literal for the '<em><b>Gsp</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GNET__GSP = eINSTANCE.getGNet_Gsp();

		/**
		 * The meta object literal for the '<em><b>Is</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GNET__IS = eINSTANCE.getGNet_Is();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GNET__NAME = eINSTANCE.getGNet_Name();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.GSPImpl <em>GSP</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.GSPImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getGSP()
		 * @generated
		 */
		EClass GSP = eINSTANCE.getGSP();

		/**
		 * The meta object literal for the '<em><b>AS</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GSP__AS = eINSTANCE.getGSP_AS();

		/**
		 * The meta object literal for the '<em><b>MS</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GSP__MS = eINSTANCE.getGSP_MS();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.ISImpl <em>IS</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.ISImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getIS()
		 * @generated
		 */
		EClass IS = eINSTANCE.getIS();

		/**
		 * The meta object literal for the '<em><b>Nodes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IS__NODES = eINSTANCE.getIS_Nodes();

		/**
		 * The meta object literal for the '<em><b>Arcs</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IS__ARCS = eINSTANCE.getIS_Arcs();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.TransitionImpl <em>Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.TransitionImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getTransition()
		 * @generated
		 */
		EClass TRANSITION = eINSTANCE.getTransition();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSITION__CONDITION = eINSTANCE.getTransition_Condition();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.PlaceImpl <em>Place</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.PlaceImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getPlace()
		 * @generated
		 */
		EClass PLACE = eINSTANCE.getPlace();

		/**
		 * The meta object literal for the '<em><b>Tokens</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLACE__TOKENS = eINSTANCE.getPlace_Tokens();

		/**
		 * The meta object literal for the '<em><b>Is Local Token</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLACE__IS_LOCAL_TOKEN = eINSTANCE.getPlace_IsLocalToken();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.ArcImpl <em>Arc</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.ArcImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getArc()
		 * @generated
		 */
		EClass ARC = eINSTANCE.getArc();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ARC__SOURCE = eINSTANCE.getArc_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ARC__TARGET = eINSTANCE.getArc_Target();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.NodeImpl <em>Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.NodeImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getNode()
		 * @generated
		 */
		EClass NODE = eINSTANCE.getNode();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE__NAME = eINSTANCE.getNode_Name();

		/**
		 * The meta object literal for the '<em><b>Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE__ACTION = eINSTANCE.getNode_Action();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.GPImpl <em>GP</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.GPImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getGP()
		 * @generated
		 */
		EClass GP = eINSTANCE.getGP();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.NPImpl <em>NP</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.NPImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getNP()
		 * @generated
		 */
		EClass NP = eINSTANCE.getNP();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.ISPImpl <em>ISP</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.ISPImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getISP()
		 * @generated
		 */
		EClass ISP = eINSTANCE.getISP();

		/**
		 * The meta object literal for the '<em><b>Invoked</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ISP__INVOKED = eINSTANCE.getISP_Invoked();

		/**
		 * The meta object literal for the '<em><b>Using</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ISP__USING = eINSTANCE.getISP_Using();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.GNets_SpecificationImpl <em>GNets Specification</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.GNets_SpecificationImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getGNets_Specification()
		 * @generated
		 */
		EClass GNETS_SPECIFICATION = eINSTANCE.getGNets_Specification();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GNETS_SPECIFICATION__NAME = eINSTANCE.getGNets_Specification_Name();

		/**
		 * The meta object literal for the '<em><b>Gnets</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GNETS_SPECIFICATION__GNETS = eINSTANCE.getGNets_Specification_Gnets();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.AttributeImpl <em>Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.AttributeImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getAttribute()
		 * @generated
		 */
		EClass ATTRIBUTE = eINSTANCE.getAttribute();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__NAME = eINSTANCE.getAttribute_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__TYPE = eINSTANCE.getAttribute_Type();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.impl.MethodImpl <em>Method</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.impl.MethodImpl
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getMethod()
		 * @generated
		 */
		EClass METHOD = eINSTANCE.getMethod();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METHOD__NAME = eINSTANCE.getMethod_Name();

		/**
		 * The meta object literal for the '<em><b>Initials</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METHOD__INITIALS = eINSTANCE.getMethod_Initials();

		/**
		 * The meta object literal for the '<em><b>Finals</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METHOD__FINALS = eINSTANCE.getMethod_Finals();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METHOD__ATTRIBUTES = eINSTANCE.getMethod_Attributes();

		/**
		 * The meta object literal for the '{@link ogr.eclipse.gnets.Type <em>Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ogr.eclipse.gnets.Type
		 * @see ogr.eclipse.gnets.impl.GnetsPackageImpl#getType()
		 * @generated
		 */
		EEnum TYPE = eINSTANCE.getType();

	}

} //GnetsPackage
