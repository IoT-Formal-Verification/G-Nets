/**
 */
package ogr.eclipse.gnets;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>NP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ogr.eclipse.gnets.GnetsPackage#getNP()
 * @model
 * @generated
 */
public interface NP extends Place {
} // NP
