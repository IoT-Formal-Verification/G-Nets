/**
 */
package ogr.eclipse.gnets;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>GSP</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ogr.eclipse.gnets.GSP#getAS <em>AS</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.GSP#getMS <em>MS</em>}</li>
 * </ul>
 *
 * @see ogr.eclipse.gnets.GnetsPackage#getGSP()
 * @model
 * @generated
 */
public interface GSP extends EObject {
	/**
	 * Returns the value of the '<em><b>AS</b></em>' containment reference list.
	 * The list contents are of type {@link ogr.eclipse.gnets.Attribute}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>AS</em>' containment reference list.
	 * @see ogr.eclipse.gnets.GnetsPackage#getGSP_AS()
	 * @model containment="true"
	 * @generated
	 */
	EList<Attribute> getAS();

	/**
	 * Returns the value of the '<em><b>MS</b></em>' containment reference list.
	 * The list contents are of type {@link ogr.eclipse.gnets.Method}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>MS</em>' containment reference list.
	 * @see ogr.eclipse.gnets.GnetsPackage#getGSP_MS()
	 * @model containment="true"
	 * @generated
	 */
	EList<Method> getMS();

} // GSP
