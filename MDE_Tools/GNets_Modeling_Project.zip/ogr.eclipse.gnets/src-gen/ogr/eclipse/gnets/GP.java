/**
 */
package ogr.eclipse.gnets;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>GP</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ogr.eclipse.gnets.GnetsPackage#getGP()
 * @model
 * @generated
 */
public interface GP extends Place {
} // GP
