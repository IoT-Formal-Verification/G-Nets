/**
 */
package ogr.eclipse.gnets;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Place</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ogr.eclipse.gnets.Place#isIsLocalToken <em>Is Local Token</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.Place#getTokens <em>Tokens</em>}</li>
 * </ul>
 *
 * @see ogr.eclipse.gnets.GnetsPackage#getPlace()
 * @model abstract="true"
 * @generated
 */
public interface Place extends Node {
	/**
	 * Returns the value of the '<em><b>Tokens</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tokens</em>' attribute.
	 * @see #setTokens(EList)
	 * @see ogr.eclipse.gnets.GnetsPackage#getPlace_Tokens()
	 * @model many="false" transient="true"
	 * @generated
	 */
	EList getTokens();

	/**
	 * Sets the value of the '{@link ogr.eclipse.gnets.Place#getTokens <em>Tokens</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tokens</em>' attribute.
	 * @see #getTokens()
	 * @generated
	 */
	void setTokens(EList value);

	/**
	 * Returns the value of the '<em><b>Is Local Token</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Local Token</em>' attribute.
	 * @see #setIsLocalToken(boolean)
	 * @see ogr.eclipse.gnets.GnetsPackage#getPlace_IsLocalToken()
	 * @model
	 * @generated
	 */
	boolean isIsLocalToken();

	/**
	 * Sets the value of the '{@link ogr.eclipse.gnets.Place#isIsLocalToken <em>Is Local Token</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Local Token</em>' attribute.
	 * @see #isIsLocalToken()
	 * @generated
	 */
	void setIsLocalToken(boolean value);

} // Place
