/**
 */
package ogr.eclipse.gnets;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Method</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ogr.eclipse.gnets.Method#getName <em>Name</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.Method#getInitials <em>Initials</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.Method#getFinals <em>Finals</em>}</li>
 *   <li>{@link ogr.eclipse.gnets.Method#getAttributes <em>Attributes</em>}</li>
 * </ul>
 *
 * @see ogr.eclipse.gnets.GnetsPackage#getMethod()
 * @model
 * @generated
 */
public interface Method extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ogr.eclipse.gnets.GnetsPackage#getMethod_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ogr.eclipse.gnets.Method#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Initials</b></em>' reference list.
	 * The list contents are of type {@link ogr.eclipse.gnets.Place}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initials</em>' reference list.
	 * @see ogr.eclipse.gnets.GnetsPackage#getMethod_Initials()
	 * @model
	 * @generated
	 */
	EList<Place> getInitials();

	/**
	 * Returns the value of the '<em><b>Finals</b></em>' reference list.
	 * The list contents are of type {@link ogr.eclipse.gnets.Place}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Finals</em>' reference list.
	 * @see ogr.eclipse.gnets.GnetsPackage#getMethod_Finals()
	 * @model
	 * @generated
	 */
	EList<Place> getFinals();

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' reference list.
	 * The list contents are of type {@link ogr.eclipse.gnets.Attribute}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' reference list.
	 * @see ogr.eclipse.gnets.GnetsPackage#getMethod_Attributes()
	 * @model
	 * @generated
	 */
	EList<Attribute> getAttributes();

} // Method
